|| [Home](Home) || [Features](Features) || **+Requirements+** || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Credits](Credits) || [Contact](Contact) ||

# Requirements
* PHP version 5.2 or higher