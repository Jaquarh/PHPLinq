|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || **+Contribute+** || [Credits](Credits) || [Contact](Contact) ||

# Contribute to PHPLinq

## Contribute bugs, feature requests, ...
Found a bug? Have a feature request? Please create a work item on [http://www.codeplex.com/PHPLinq/WorkItem/AdvancedList.aspx](http://www.codeplex.com/PHPLinq/WorkItem/AdvancedList.aspx).

If you have a small piece of code that can solve a problem / add a new feature, you can also communicate this to us using a work item.

## Have a patch?
Created a patch for a bug or feature? Please upload it on [http://www.codeplex.com/PHPLinq/SourceControl/UploadPatch.aspx](http://www.codeplex.com/PHPLinq/SourceControl/UploadPatch.aspx).
Patches can be CodePlex patches or Subversion patches.

Here's how to create a patch:
- CodePlex: [http://www.codeplex.com/CodePlexClient/Wiki/View.aspx?title=HowToContribute](http://www.codeplex.com/CodePlexClient/Wiki/View.aspx?title=HowToContribute)
- Subversion: [http://tortoisesvn.net/docs/release/TortoiseSVN_en/tsvn-dug-patch.html](http://tortoisesvn.net/docs/release/TortoiseSVN_en/tsvn-dug-patch.html)
