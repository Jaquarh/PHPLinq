|| [Home](Home) || **+Features+** || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Credits](Credits) || [Contact](Contact) ||

# Features
PHPLinq currently features:
* LINQ operators
	* select
	* take
	* skip
	* orderBy / orderByDescending
	* thenBy / thenByDescending
* Lambda expressions
* Anonymous types
* ...

Check the [Examples](Examples) for a quick example!