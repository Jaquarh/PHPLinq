|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || **+Credits+** || [Contact](Contact) ||

# Credits
## Team members
* Maarten Balliauw, Project manager / Developer, [http://blog.maartenballiauw.be](http://blog.maartenballiauw.be)
Check [http://www.codeplex.com/PHPLinq/Project/ProjectPeople.aspx](http://www.codeplex.com/PHPLinq/Project/ProjectPeople.aspx) for a complete list of team members.
