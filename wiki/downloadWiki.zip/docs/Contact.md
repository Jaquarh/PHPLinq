|| [Home](Home) || [Features](Features) || [Requirements](Requirements) || [Examples](Examples) || [FAQ](FAQ) || [Contribute](Contribute) || [Credits](Credits) || **+Contact+** ||

# Project contact details
## Contact project manager / Contribute
Contacting the project manager can be done using this e-mail address: [mailto:maarten@phpexcel.net](mailto:maarten@phpexcel.net)

## Project website
Some useful internet addresses:
* Project homepage [http://www.codeplex.com/PHPLinq](http://www.codeplex.com/PHPLinq)
* Project releases [http://www.codeplex.com/PHPLinq/Release/ProjectReleases.aspx](http://www.codeplex.com/PHPLinq/Release/ProjectReleases.aspx)
* Discussion forum [http://www.codeplex.com/PHPLinq/Thread/List.aspx](http://www.codeplex.com/PHPLinq/Thread/List.aspx)
* Issue tracker [http://www.codeplex.com/PHPLinq/WorkItem/List.aspx](http://www.codeplex.com/PHPLinq/WorkItem/List.aspx)

## Feature requests
Please post feature requests to this URL: [http://www.codeplex.com/PHPLinq/WorkItem/List.aspx](http://www.codeplex.com/PHPLinq/WorkItem/List.aspx). Make sure you do not create a duplicate request.

## Issue tracker
When you found an issue regarding this project, please report it using this URL: [http://www.codeplex.com/PHPLinq/WorkItem/List.aspx](http://www.codeplex.com/PHPLinq/WorkItem/List.aspx).