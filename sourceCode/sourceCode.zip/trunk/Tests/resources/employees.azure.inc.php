<?php
/**
 * PHPLinq
 *
 * Copyright (c) 2008 - 2011 PHPLinq
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPLinq
 * @package    PHPLinq
 * @copyright  Copyright (c) 2008 - 2011 PHPLinq (http://www.codeplex.com/PHPLinq)
 * @license    http://www.gnu.org/licenses/lgpl.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Microsoft_Azure_Storage_Table */
require_once 'Microsoft/Azure/Storage/Table.php';

/** Setup Azure */
require_once 'azure.inc.php';

// Create data source
$employees = null;
require_once 'employees.inc.php';

if ($createTables) {
	$storageClient->createTable('employees');
	foreach ($employees as $employee) {
		$azureEmployee = AzureEmployee::fromEmployee($employee);
		$storageClient->insertEntity('employees', $azureEmployee);
	}
}

// AzureEmployee class
class AzureEmployee extends Microsoft_Azure_Storage_TableEntity {
    /**
     * @azure Id Edm.Int64
     */
	public $Id;
	
    /**
     * @azure DepartmentId Edm.Int64
     */
	public $DepartmentId;
	
    /**
     * @azure ManagerId Edm.Int64
     */
	public $ManagerId;
	
    /**
     * @azure Name
     */
	public $Name;
	
    /**
     * @azure Email
     */
	public $Email;
	
    /**
     * @azure Age Edm.Int64
     */
	public $Age;
	
	public static function fromEmployee($employee) {
		$azureEmployee = new AzureEmployee('phplinq', $employee->Id);
		$azureEmployee->Id = $employee->Id;
		$azureEmployee->DepartmentId = $employee->DepartmentId;
		$azureEmployee->ManagerId = $employee->ManagerId;
		$azureEmployee->Name = $employee->Name;
		$azureEmployee->Email = $employee->Email;
		$azureEmployee->Age = $employee->Age;
		
		return $azureEmployee;
	}
}