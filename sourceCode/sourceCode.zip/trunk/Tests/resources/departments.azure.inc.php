<?php
/**
 * PHPLinq
 *
 * Copyright (c) 2008 - 2011 PHPLinq
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPLinq
 * @package    PHPLinq
 * @copyright  Copyright (c) 2008 - 2011 PHPLinq (http://www.codeplex.com/PHPLinq)
 * @license    http://www.gnu.org/licenses/lgpl.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Microsoft_WindowsAzure_Storage_Table */
require_once 'Microsoft/WindowsAzure/Storage/Table.php';

/** Setup Azure */
require_once 'azure.inc.php';

// Create data source
$departments = null;
require_once 'departments.inc.php';

if ($createTables) {
	$storageClient->createTable('departments');
	foreach ($departments as $department) {
		$azureDepartment = AzureDepartment::fromDepartment($department);
		$storageClient->insertEntity('departments', $azureDepartment);
	}
}

// AzureDepartment class
class AzureDepartment extends Microsoft_WindowsAzure_Storage_TableEntity {
    /**
     * @azure Id Edm.Int64
     */
	public $Id;
	
    /**
     * @azure Name
     */
	public $Name;
	
	public static function fromDepartment($department) {
		$azureDepartment = new AzureDepartment('phplinq', $department->Id);
		$azureDepartment->Id = $department->Id;
		$azureDepartment->Name = $department->Name;
		
		return $azureDepartment;
	}
}