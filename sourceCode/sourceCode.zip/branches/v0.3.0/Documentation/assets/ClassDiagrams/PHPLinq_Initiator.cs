﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagrams
{
    public class PHPLinq_Initiator
    {
        public from from
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public PHPLinq_ILinqProvider creates
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
