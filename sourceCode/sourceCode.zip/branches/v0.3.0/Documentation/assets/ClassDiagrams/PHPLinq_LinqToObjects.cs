﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagrams
{
    public class PHPLinq_LinqToObjects : PHPLinq_ILinqProvider
    {
    }
}
