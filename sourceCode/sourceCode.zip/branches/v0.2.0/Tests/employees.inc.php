<?php
/**
 * PHPLinq
 *
 * Copyright (c) 2008 PHPLinq
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPLinq
 * @package    PHPLinq
 * @copyright  Copyright (c) 2008 PHPLinq (http://www.codeplex.com/PHPLinq)
 * @license    http://www.gnu.org/licenses/lgpl.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

// Custom class
class Employee {
	public $Name;
	public $Email;
	public $Age;
  
	public function __construct($name = '', $email = '', $age = '') {
		$this->Name 	= $name;
		$this->Email 	= $email;
		$this->Age		= $age;
	}
}

// Create data source
$employees = array(
	new Employee('Maarten', 'maarten@example.com', 24),
	new Employee('Paul', 'paul@example.com', 30),
	new Employee('Bill', 'bill.a@example.com', 29),
	new Employee('Bill', 'bill.g@example.com', 28),
	new Employee('Xavier', 'xavier@example.com', 40)
);